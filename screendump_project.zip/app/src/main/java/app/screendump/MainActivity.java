package app.screendump;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView status;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        int p = (int) (20 * getResources().getDisplayMetrics().density);
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(p, p, p, p);
        sv.addView(col);

        TextView title = new TextView(this);
        title.setText("دامپ صفحه");
        title.setTextSize(24);
        title.setGravity(Gravity.START);
        col.addView(title);

        status = new TextView(this);
        status.setTextSize(15);
        status.setPadding(0, p / 2, 0, p / 2);
        col.addView(status);

        Button open = new Button(this);
        open.setText("باز کردن تنظیمات دسترسی");
        open.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        col.addView(open);

        TextView help = new TextView(this);
        help.setTextSize(15);
        help.setPadding(0, p, 0, 0);
        help.setText(
                "۱) دکمه‌ی بالا را بزن و «دامپ صفحه» را روشن کن.\n\n"
                + "۲) برنامه‌ی ایرانسل من را باز کن و برو به بخش بسته‌ها.\n\n"
                + "۳) روی نوار شناور سمت راست صفحه سه دکمه هست:\n"
                + "• اسکن: اول تا بالای لیست می‌رود، بعد قدم‌به‌قدم پایین می‌رود و از هر مرحله متن‌ها و اسکرین‌شات می‌گیرد تا ته لیست. (دوباره بزنی متوقف می‌شود)\n"
                + "• ثبت: فقط همین یک صفحه را ثبت می‌کند. برای هر تب (اینترنت، پیشنهادی، رایگان، ...) جدا بزن.\n"
                + "• ذخیره: همه‌ی ثبت‌ها را در یک فایل zip می‌ریزد.\n\n"
                + "۴) فایل در پوشه‌ی Download/ScreenDump ساخته می‌شود. آن را برای من بفرست.");
        col.addView(help);
        setContentView(sv);
    }

    @Override protected void onResume() {
        super.onResume();
        status.setText(DumpService.inst != null ? "● سرویس روشن است" : "● سرویس خاموش است");
    }
}
