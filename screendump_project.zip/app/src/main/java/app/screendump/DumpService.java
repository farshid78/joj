package app.screendump;

import android.accessibilityservice.AccessibilityService;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Diagnostic tool: dumps EVERY node of the foreground app (text, desc, id, bounds, flags, actions ...)
 * plus a screenshot, step by step while scrolling, into one zip in Downloads/ScreenDump.
 */
public class DumpService extends AccessibilityService {
    static volatile DumpService inst;

    private static final int MAX_NODES = 9000;
    private static final int MAX_STEPS = 80;

    private final Handler h = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private LinearLayout panel;
    private TextView bAuto, bShot, bSave;
    private boolean busy, auto;
    private ZipOutputStream zip;
    private String zipName = "";
    private int steps, lastSig, autoStored;
    private final StringBuilder summary = new StringBuilder();

    static final class Snap {
        String text = "";
        String pkg = "";
        int sig;
        int nodes;
        byte[] jpg;
        AccessibilityNodeInfo scroll;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}

    @Override public void onInterrupt() {}

    @Override protected void onServiceConnected() {
        inst = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        buildPanel();
    }

    @Override public boolean onUnbind(Intent i) {
        inst = null;
        auto = false;
        try {
            if (panel != null && wm != null) wm.removeView(panel);
        } catch (Exception ignored) {}
        try {
            if (zip != null) zip.close();
        } catch (Exception ignored) {}
        zip = null;
        return super.onUnbind(i);
    }

    // ------------------------------------------------------------------ floating panel

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private TextView btn(String t, View.OnClickListener l) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextColor(Color.WHITE);
        v.setTextSize(13);
        v.setGravity(Gravity.CENTER);
        v.setMinWidth(dp(64));
        v.setPadding(dp(8), dp(12), dp(8), dp(12));
        v.setOnClickListener(l);
        return v;
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE61B2433);
        bg.setCornerRadius(dp(14));
        panel.setBackground(bg);
        bAuto = btn("اسکن", v -> startAuto());
        bShot = btn("ثبت", v -> manualShot());
        bSave = btn("ذخیره", v -> finishSession());
        panel.addView(bAuto);
        panel.addView(bShot);
        panel.addView(bSave);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
        try {
            wm.addView(panel, lp);
        } catch (Exception e) {
            toast("نمایش نوار شناور ممکن نشد: " + e.getMessage());
        }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private void updateSaveLabel() {
        bSave.setText(steps > 0 ? "ذخیره (" + steps + ")" : "ذخیره");
    }

    // ------------------------------------------------------------------ actions

    private void manualShot() {
        if (busy || auto) {
            toast("اسکن در حال انجام است");
            return;
        }
        busy = true;
        capture(true, s -> {
            busy = false;
            if (s == null) {
                toast("صفحه‌ای برای ثبت پیدا نشد");
                return;
            }
            store(s);
            toast("ثبت شد: " + steps);
        });
    }

    private void startAuto() {
        if (auto) {
            auto = false;
            toast("در حال توقف ...");
            return;
        }
        if (busy) return;
        auto = true;
        busy = true;
        autoStored = 0;
        lastSig = 0;
        bAuto.setText("توقف");
        toast("اول می‌رود تا بالای لیست، بعد پایین می‌آید");
        upPhase(0);
    }

    private void endAuto(String why) {
        auto = false;
        busy = false;
        bAuto.setText("اسکن");
        updateSaveLabel();
        toast(why + " (" + autoStored + " مرحله). برای ساختن فایل «ذخیره» را بزن");
    }

    /** scroll to the top of the main list first, no screenshots */
    private void upPhase(int n) {
        if (!auto) {
            endAuto("متوقف شد");
            return;
        }
        Snap s = dumpAll();
        if (s == null) {
            endAuto("پنجره‌ای پیدا نشد");
            return;
        }
        boolean atTop = s.scroll == null || n >= 40 || (n > 0 && s.sig == lastSig);
        lastSig = s.sig;
        if (!atTop) {
            boolean ok = s.scroll.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
            if (ok) {
                h.postDelayed(() -> upPhase(n + 1), 700);
                return;
            }
        }
        lastSig = 0;
        h.postDelayed(this::downPhase, 500);
    }

    /** capture, scroll one page, repeat until the content stops changing */
    private void downPhase() {
        if (!auto) {
            endAuto("متوقف شد");
            return;
        }
        capture(true, s -> {
            if (s == null) {
                endAuto("پنجره‌ای پیدا نشد");
                return;
            }
            boolean dup = autoStored > 0 && s.sig == lastSig;
            if (!dup) {
                store(s);
                autoStored++;
                lastSig = s.sig;
            }
            if (dup || autoStored >= MAX_STEPS || s.scroll == null) {
                endAuto("به انتهای لیست رسید");
                return;
            }
            boolean ok = s.scroll.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);
            if (!ok) {
                endAuto("به انتهای لیست رسید");
                return;
            }
            h.postDelayed(this::downPhase, 1200);
        });
    }

    // ------------------------------------------------------------------ capture

    private void capture(boolean withShot, Consumer<Snap> done) {
        if (!withShot) {
            done.accept(dumpAll());
            return;
        }
        panel.setVisibility(View.INVISIBLE);
        h.postDelayed(() -> {
            final Snap s = dumpAll();
            if (s == null) {
                panel.setVisibility(View.VISIBLE);
                done.accept(null);
                return;
            }
            shot(jpg -> {
                s.jpg = jpg;
                panel.setVisibility(View.VISIBLE);
                done.accept(s);
            });
        }, 350);
    }

    private void shot(final Consumer<byte[]> cb) {
        if (Build.VERSION.SDK_INT < 30) {
            cb.accept(null);
            return;
        }
        final boolean[] done = {false};
        final Runnable timeout = () -> {
            if (!done[0]) {
                done[0] = true;
                cb.accept(null);
            }
        };
        h.postDelayed(timeout, 4000);
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult r) {
                    byte[] out = null;
                    try {
                        Bitmap hw = Bitmap.wrapHardwareBuffer(r.getHardwareBuffer(), r.getColorSpace());
                        Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        sw.compress(Bitmap.CompressFormat.JPEG, 70, bo);
                        out = bo.toByteArray();
                        r.getHardwareBuffer().close();
                    } catch (Throwable ignored) {}
                    if (!done[0]) {
                        done[0] = true;
                        h.removeCallbacks(timeout);
                        cb.accept(out);
                    }
                }

                @Override public void onFailure(int code) {
                    if (!done[0]) {
                        done[0] = true;
                        h.removeCallbacks(timeout);
                        cb.accept(null);
                    }
                }
            });
        } catch (Throwable t) {
            if (!done[0]) {
                done[0] = true;
                h.removeCallbacks(timeout);
                cb.accept(null);
            }
        }
    }

    // ------------------------------------------------------------------ tree dump

    private Snap dumpAll() {
        Snap s = new Snap();
        StringBuilder sb = new StringBuilder();
        StringBuilder sig = new StringBuilder();
        DisplayMetrics dm = getResources().getDisplayMetrics();
        sb.append("time=").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date()))
                .append(" screen=").append(dm.widthPixels).append('x').append(dm.heightPixels)
                .append(" density=").append(dm.density).append(" sdk=").append(Build.VERSION.SDK_INT).append('\n');
        List<AccessibilityNodeInfo> scrolls = new ArrayList<>();
        int[] cnt = {0};

        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                int type = w.getType();
                if (type == AccessibilityWindowInfo.TYPE_INPUT_METHOD
                        || type == AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY) continue;
                AccessibilityNodeInfo root = w.getRoot();
                if (root == null) continue;
                String pkg = String.valueOf(root.getPackageName());
                if (pkg.equals(getPackageName())) continue;
                Rect b = new Rect();
                w.getBoundsInScreen(b);
                sb.append("\n##### WINDOW id=").append(w.getId()).append(" type=").append(type)
                        .append(" layer=").append(w.getLayer()).append(" active=").append(w.isActive())
                        .append(" focused=").append(w.isFocused()).append(" pkg=").append(pkg)
                        .append(" title=").append(w.getTitle()).append(" bounds=").append(b.flattenToString()).append('\n');
                boolean app = type == AccessibilityWindowInfo.TYPE_APPLICATION;
                if (app && (s.pkg.isEmpty() || w.isActive())) s.pkg = pkg;
                dump(root, 0, cnt, sb, sig, scrolls, app);
            }
        }
        if (cnt[0] == 0) {
            AccessibilityNodeInfo root = getRootInActiveWindow();
            if (root != null && !String.valueOf(root.getPackageName()).equals(getPackageName())) {
                s.pkg = String.valueOf(root.getPackageName());
                sb.append("\n##### ACTIVE ROOT pkg=").append(s.pkg).append('\n');
                dump(root, 0, cnt, sb, sig, scrolls, true);
            }
        }
        if (cnt[0] == 0) return null;
        s.nodes = cnt[0];
        s.sig = sig.toString().hashCode();
        s.scroll = pickScroll(scrolls);
        s.text = sb.toString();
        return s;
    }

    private static boolean hasAction(AccessibilityNodeInfo n, int id) {
        List<AccessibilityNodeInfo.AccessibilityAction> l = n.getActionList();
        if (l == null) return false;
        for (AccessibilityNodeInfo.AccessibilityAction a : l) if (a.getId() == id) return true;
        return false;
    }

    private AccessibilityNodeInfo pickScroll(List<AccessibilityNodeInfo> l) {
        AccessibilityNodeInfo best = null;
        long bs = -1;
        Rect r = new Rect();
        for (AccessibilityNodeInfo n : l) {
            n.getBoundsInScreen(r);
            long score = (long) r.width() * (long) r.height();
            if (hasAction(n, AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.getId())) score *= 4;
            if (score > bs) {
                bs = score;
                best = n;
            }
        }
        return best;
    }

    private static void kv(StringBuilder sb, String k, CharSequence v) {
        if (v == null || v.length() == 0) return;
        String s = v.toString().replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "").replace("\"", "'");
        if (s.length() > 3000) s = s.substring(0, 3000) + "...";
        sb.append(' ').append(k).append("=\"").append(s).append('"');
    }

    private static String shortCls(CharSequence c) {
        if (c == null) return "?";
        String s = c.toString();
        int i = s.lastIndexOf('.');
        return i >= 0 ? s.substring(i + 1) : s;
    }

    private void dump(AccessibilityNodeInfo n, int depth, int[] cnt, StringBuilder sb, StringBuilder sig,
                      List<AccessibilityNodeInfo> scrolls, boolean app) {
        if (n == null || depth > 80 || cnt[0] >= MAX_NODES) return;
        int idx = cnt[0]++;
        Rect b = new Rect();
        n.getBoundsInScreen(b);
        for (int i = 0; i < depth; i++) sb.append(' ');
        sb.append('#').append(idx).append(' ').append(shortCls(n.getClassName()));
        kv(sb, "id", n.getViewIdResourceName());
        kv(sb, "text", n.getText());
        kv(sb, "desc", n.getContentDescription());
        kv(sb, "hint", n.getHintText());
        kv(sb, "err", n.getError());
        kv(sb, "tip", n.getTooltipText());
        kv(sb, "pane", n.getPaneTitle());
        if (Build.VERSION.SDK_INT >= 30) kv(sb, "state", n.getStateDescription());
        sb.append(" b=").append(b.left).append(',').append(b.top).append(',').append(b.right).append(',').append(b.bottom);
        boolean vis = n.isVisibleToUser();
        sb.append(" vis=").append(vis ? 1 : 0);
        StringBuilder f = new StringBuilder();
        if (n.isClickable()) f.append("CLK,");
        if (n.isLongClickable()) f.append("LCK,");
        if (n.isScrollable()) f.append("SCR,");
        if (n.isCheckable()) f.append("CHKBL,");
        if (n.isChecked()) f.append("CHECKED,");
        if (!n.isEnabled()) f.append("DISABLED,");
        if (n.isSelected()) f.append("SEL,");
        if (n.isFocusable()) f.append("FOC,");
        if (n.isEditable()) f.append("EDIT,");
        if (n.isPassword()) f.append("PWD,");
        if (!n.isImportantForAccessibility()) f.append("NOTIMP,");
        if (f.length() > 0) sb.append(" flags=").append(f, 0, f.length() - 1);
        sb.append(" draw=").append(n.getDrawingOrder());
        List<AccessibilityNodeInfo.AccessibilityAction> acts = n.getActionList();
        if (acts != null && !acts.isEmpty()) {
            StringBuilder a = new StringBuilder();
            for (AccessibilityNodeInfo.AccessibilityAction x : acts) {
                int id = x.getId();
                if (id == AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.getId()) a.append("UP,");
                else if (id == AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.getId()) a.append("DOWN,");
                else if (id == AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT.getId()) a.append("LEFT,");
                else if (id == AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT.getId()) a.append("RIGHT,");
            }
            if (a.length() > 0) sb.append(" scroll=").append(a, 0, a.length() - 1);
        }
        AccessibilityNodeInfo.CollectionInfo ci = n.getCollectionInfo();
        if (ci != null) sb.append(" coll=").append(ci.getRowCount()).append('x').append(ci.getColumnCount());
        AccessibilityNodeInfo.CollectionItemInfo ii = n.getCollectionItemInfo();
        if (ii != null) {
            sb.append(" item=r").append(ii.getRowIndex()).append("c").append(ii.getColumnIndex())
                    .append(" span=").append(ii.getRowSpan()).append('x').append(ii.getColumnSpan());
        }
        int kids = n.getChildCount();
        sb.append(" kids=").append(kids).append('\n');

        if (app && vis) {
            CharSequence t = n.getText();
            CharSequence d = n.getContentDescription();
            if (t != null) sig.append(t).append('|');
            if (d != null) sig.append(d).append('|');
        }
        if (app && vis && n.isScrollable()) scrolls.add(n);

        for (int i = 0; i < kids; i++) {
            AccessibilityNodeInfo c = n.getChild(i);
            if (c == null) {
                for (int k = 0; k <= depth; k++) sb.append(' ');
                sb.append("(null child ").append(i).append(")\n");
            } else {
                dump(c, depth + 1, cnt, sb, sig, scrolls, app);
            }
        }
    }

    // ------------------------------------------------------------------ zip session

    private void ensureSession() throws Exception {
        if (zip != null) return;
        String ts = new SimpleDateFormat("MMdd_HHmmss", Locale.US).format(new Date());
        zipName = "screendump_" + ts + ".zip";
        ContentValues v = new ContentValues();
        v.put(MediaStore.Downloads.DISPLAY_NAME, zipName);
        v.put(MediaStore.Downloads.MIME_TYPE, "application/zip");
        v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ScreenDump");
        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        OutputStream os = getContentResolver().openOutputStream(u);
        zip = new ZipOutputStream(os);
        steps = 0;
        summary.setLength(0);
    }

    private void put(String name, byte[] data) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(data);
        zip.closeEntry();
    }

    private void store(Snap s) {
        try {
            ensureSession();
            steps++;
            String n = String.format(Locale.US, "%02d", steps);
            put(n + "_tree.txt", s.text.getBytes(StandardCharsets.UTF_8));
            if (s.jpg != null) put(n + "_shot.jpg", s.jpg);
            summary.append(n).append(" pkg=").append(s.pkg).append(" nodes=").append(s.nodes)
                    .append(" screenshot=").append(s.jpg != null).append('\n');
        } catch (Exception e) {
            toast("خطا در ذخیره: " + e.getMessage());
        }
        updateSaveLabel();
    }

    private void finishSession() {
        if (busy || auto) {
            toast("اول اسکن را متوقف کن یا صبر کن تمام شود");
            return;
        }
        if (zip == null) {
            toast("هنوز چیزی ثبت نشده");
            return;
        }
        try {
            put("summary.txt", summary.toString().getBytes(StandardCharsets.UTF_8));
            zip.close();
            toast("ذخیره شد: Download/ScreenDump/" + zipName);
        } catch (Exception e) {
            toast("خطا در بستن فایل: " + e.getMessage());
        }
        zip = null;
        steps = 0;
        updateSaveLabel();
    }
}
